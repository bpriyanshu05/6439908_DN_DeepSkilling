package com.example.MockingAndStubbing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockingAndStubbingApplicationTests {

	@Test
	void contextLoads() {
	}

}
