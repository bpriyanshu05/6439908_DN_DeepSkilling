package com.example.MockingAndStubbing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockingAndStubbingApplication {

	public static void main(String[] args) {
		SpringApplication.run(MockingAndStubbingApplication.class, args);
	}

}
