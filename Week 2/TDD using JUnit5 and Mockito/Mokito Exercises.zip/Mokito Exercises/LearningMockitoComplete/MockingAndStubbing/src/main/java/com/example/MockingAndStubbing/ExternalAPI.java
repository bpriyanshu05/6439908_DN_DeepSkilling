package com.example.MockingAndStubbing;

public interface ExternalAPI {
    String getData();
}
