package com.example.MokitoMockDependency;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MokitoMockDependencyApplication {

	public static void main(String[] args) {
		SpringApplication.run(MokitoMockDependencyApplication.class, args);
	}

}
