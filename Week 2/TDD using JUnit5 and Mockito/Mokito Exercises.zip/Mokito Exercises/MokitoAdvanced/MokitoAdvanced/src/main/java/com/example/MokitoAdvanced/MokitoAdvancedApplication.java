package com.example.MokitoAdvanced;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MokitoAdvancedApplication {

	public static void main(String[] args) {
		SpringApplication.run(MokitoAdvancedApplication.class, args);
	}

}
