package com.example.MokitoAdvanced;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MokitoAdvancedApplicationTests {

	@Test
	void contextLoads() {
	}

}
